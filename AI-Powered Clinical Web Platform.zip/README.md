
  # AI-Powered Clinical Web Platform

  This is a code bundle for AI-Powered Clinical Web Platform. The original project is available at https://www.figma.com/design/hQ7pJxkzOdLBRo0hVJpTKv/AI-Powered-Clinical-Web-Platform.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  